// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Extract bloom highlights\n", stdout);
  return lionss_run_workload("BloomThreshold");
}
