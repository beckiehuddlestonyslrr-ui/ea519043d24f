// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Rotate flintlock keys"); }
int main(){
  announce();
  return lionss_run_workload("flintlock");
}
