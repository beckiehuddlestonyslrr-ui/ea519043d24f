// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Erase SPI sectors"); }
int main(){
  announce();
  return lionss_run_workload("spiFlashErase");
}
