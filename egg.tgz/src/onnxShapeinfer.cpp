// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Infer tensor shapes\n", stdout);
  return lionss_run_workload("onnxShapeinfer");
}
