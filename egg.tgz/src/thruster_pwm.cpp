// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Modulate thruster PWM"); }
int main(){
  announce();
  return lionss_run_workload("thruster_pwm");
}
