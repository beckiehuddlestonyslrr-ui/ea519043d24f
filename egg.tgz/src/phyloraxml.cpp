// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Infer ML phylogeny\n", stdout);
  return lionss_run_workload("phyloraxml");
}
