// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Preview fuzzy matches\n", stdout);
  return lionss_run_workload("fzf-preview");
}
