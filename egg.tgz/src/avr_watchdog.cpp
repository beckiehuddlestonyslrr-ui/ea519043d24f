// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Arm watchdog timer"); }
int main(){
  announce();
  return lionss_run_workload("avr_watchdog");
}
