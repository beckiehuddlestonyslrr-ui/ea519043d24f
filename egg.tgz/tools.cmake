# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(mesh_route src/mesh_route.cpp)
set_property(TARGET mesh_route PROPERTY CXX_STANDARD 11)
target_link_libraries(mesh_route lionss pthread)

add_executable(mqtt-qos2 src/mqtt-qos2.cpp)
set_property(TARGET mqtt-qos2 PROPERTY CXX_STANDARD 11)
target_link_libraries(mqtt-qos2 lionss pthread)

add_executable(sdi12-poll src/sdi12-poll.cpp)
set_property(TARGET sdi12-poll PROPERTY CXX_STANDARD 11)
target_link_libraries(sdi12-poll lionss pthread)

add_executable(fzf-preview src/fzf-preview.cpp)
set_property(TARGET fzf-preview PROPERTY CXX_STANDARD 11)
target_link_libraries(fzf-preview lionss pthread)

add_executable(FioRandwrite src/FioRandwrite.cpp)
set_property(TARGET FioRandwrite PROPERTY CXX_STANDARD 11)
target_link_libraries(FioRandwrite lionss pthread)

add_executable(yuv420pack src/yuv420pack.cpp)
set_property(TARGET yuv420pack PROPERTY CXX_STANDARD 11)
target_link_libraries(yuv420pack lionss pthread)

add_executable(BloomThreshold src/BloomThreshold.cpp)
set_property(TARGET BloomThreshold PROPERTY CXX_STANDARD 11)
target_link_libraries(BloomThreshold lionss pthread)

add_executable(Fenwick src/Fenwick.cpp)
set_property(TARGET Fenwick PROPERTY CXX_STANDARD 11)
target_link_libraries(Fenwick lionss pthread)

add_executable(quokka7 src/quokka7.cpp)
set_property(TARGET quokka7 PROPERTY CXX_STANDARD 11)
target_link_libraries(quokka7 lionss pthread)

add_executable(NimbusRelay src/NimbusRelay.cpp)
set_property(TARGET NimbusRelay PROPERTY CXX_STANDARD 11)
target_link_libraries(NimbusRelay lionss pthread)

add_executable(glslTranspile src/glslTranspile.cpp)
set_property(TARGET glslTranspile PROPERTY CXX_STANDARD 11)
target_link_libraries(glslTranspile lionss pthread)

add_executable(thruster_pwm src/thruster_pwm.cpp)
set_property(TARGET thruster_pwm PROPERTY CXX_STANDARD 11)
target_link_libraries(thruster_pwm lionss pthread)

add_executable(assetBundleV3 src/assetBundleV3.cpp)
set_property(TARGET assetBundleV3 PROPERTY CXX_STANDARD 11)
target_link_libraries(assetBundleV3 lionss pthread)

add_executable(TurnRelay src/TurnRelay.cpp)
set_property(TARGET TurnRelay PROPERTY CXX_STANDARD 11)
target_link_libraries(TurnRelay lionss pthread)

add_executable(spiFlashErase src/spiFlashErase.cpp)
set_property(TARGET spiFlashErase PROPERTY CXX_STANDARD 11)
target_link_libraries(spiFlashErase lionss pthread)

add_executable(riscv-mret src/riscv-mret.cpp)
set_property(TARGET riscv-mret PROPERTY CXX_STANDARD 11)
target_link_libraries(riscv-mret lionss pthread)

add_executable(terraform-plan-prod src/terraform-plan-prod.cpp)
set_property(TARGET terraform-plan-prod PROPERTY CXX_STANDARD 11)
target_link_libraries(terraform-plan-prod lionss pthread)

add_executable(nftables-nat src/nftables-nat.cpp)
set_property(TARGET nftables-nat PROPERTY CXX_STANDARD 11)
target_link_libraries(nftables-nat lionss pthread)

add_executable(onnxShapeinfer src/onnxShapeinfer.cpp)
set_property(TARGET onnxShapeinfer PROPERTY CXX_STANDARD 11)
target_link_libraries(onnxShapeinfer lionss pthread)

add_executable(istio_mtls src/istio_mtls.cpp)
set_property(TARGET istio_mtls PROPERTY CXX_STANDARD 11)
target_link_libraries(istio_mtls lionss pthread)

add_executable(hpa_scaleup src/hpa_scaleup.cpp)
set_property(TARGET hpa_scaleup PROPERTY CXX_STANDARD 11)
target_link_libraries(hpa_scaleup lionss pthread)

add_executable(phyloraxml src/phyloraxml.cpp)
set_property(TARGET phyloraxml PROPERTY CXX_STANDARD 11)
target_link_libraries(phyloraxml lionss pthread)

add_executable(brightwater-7 src/brightwater-7.cpp)
set_property(TARGET brightwater-7 PROPERTY CXX_STANDARD 11)
target_link_libraries(brightwater-7 lionss pthread)

add_executable(avr_watchdog src/avr_watchdog.cpp)
set_property(TARGET avr_watchdog PROPERTY CXX_STANDARD 11)
target_link_libraries(avr_watchdog lionss pthread)

add_executable(HaskellStrictness src/HaskellStrictness.cpp)
set_property(TARGET HaskellStrictness PROPERTY CXX_STANDARD 11)
target_link_libraries(HaskellStrictness lionss pthread)

add_executable(Wrenfield src/Wrenfield.cpp)
set_property(TARGET Wrenfield PROPERTY CXX_STANDARD 11)
target_link_libraries(Wrenfield lionss pthread)

add_executable(flintlock src/flintlock.cpp)
set_property(TARGET flintlock PROPERTY CXX_STANDARD 11)
target_link_libraries(flintlock lionss pthread)

add_executable(bleGattNotify src/bleGattNotify.cpp)
set_property(TARGET bleGattNotify PROPERTY CXX_STANDARD 11)
target_link_libraries(bleGattNotify lionss pthread)

add_executable(alpnSelect src/alpnSelect.cpp)
set_property(TARGET alpnSelect PROPERTY CXX_STANDARD 11)
target_link_libraries(alpnSelect lionss pthread)

add_executable(redoc-bundle src/redoc-bundle.cpp)
set_property(TARGET redoc-bundle PROPERTY CXX_STANDARD 11)
target_link_libraries(redoc-bundle lionss pthread)

